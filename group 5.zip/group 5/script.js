// ==================== CONFIGURATION ====================
// Default admin credentials
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = 'Admin@12345'; // Change this in production!
const DEFAULT_PRICE = 50;

// Default menu items
const DEFAULT_ITEMS = [
    ["Pizza", "food", 250, null, "Pizza.webp"],
    ["Scrambled Eggs", "food", 60, null, "Scrambled Eggs.webp"],
    ["Spring Rolls", "food", 80, null, "Spring Rolls.jpg"],
    ["French Toast", "food", 40, null, "French Toast.webp"],
    ["Porridge", "food", 30, null, "Porridge.webp"],
    ["Fruit Salad", "food", 50, null, "Fruit Salad.webp"],
    ["Sandwich", "food", 70, null, "Ham_Sandwich_011-1-49227336bc074513aaf8fdbde440eafe.jpg"],
    ["Rice with Chicken", "food", 200, null, "chicken-and-rice-15.jpg"],
    ["Rice with Beef", "food", 220, null, "Rice with Beef.webp"],
    ["Shiro", "food", 35, null, "Shiro.webp"],
    ["Pasta (Meat/Vegetables)", "food", 140, null, null], // no image
    ["Fish Fillet", "food", 240, null, "Fish Fillet.jpg"],
    ["Burger (Beef/Chicken/Veg)", "food", 110, null, "Burger.jpg"],
    ["Chicken Soup", "food", 45, null, "Soup.webp"],
    ["Vegetable Soup", "food", 40, null, "Soup.webp"],
    ["Greek Salad", "food", 60, null, "Greek Salad.webp"],
    ["Garden Salad", "food", 50, null, "Garden-Salad-3.webp"],
    ["French Fries", "food", 70, null, "French Fries.webp"],
    ["Sambusa", "food", 10, null, "Sanbusa.jpg"],
    ["Injera with Wot", "food", 55, null, "Injera with wot.jpg"],
    ["Gored Gored", "food", 180, null, "Gored Gored.jpg"],
    ["Tere Sega", "food", 160, null, "Tere Sega.webp"],
    ["Kinche", "food", 25, null, "Kinche.webp"],
    ["Chechebsa", "food", 40, null, "chechebsa.webp"],
    ["Cake", "food", 65, null, "Cake.webp"],
    ["Tibs (Lamb/Beef)", "food", 220, null, "Tibs.jpg"],
    ["Fruit Platter", "food", 75, null, "Firut Platter.jpg"],
    ["Chocolate Pudding", "food", 55, null, "Chocolate Pudding.jpg"],
    ["Custard", "food", 45, null, "Custard.webp"],
    ["Firfir", "food", 35, null, "Firfir.jpg"],

    // drinks
    ["Coffee", "drink", 25, null, "Coffe.webp"],
    ["Milkshake", "drink", 50, null, "Milkshake.webp"],
    ["Lemonade", "drink", 35, null, "Lemonade.webp"],
    ["Banana Smoothie", "drink", 40, null, "Banana Smoothie.webp"],
    ["Rum", "drink", 90, null, "Rum.jpg"],
    ["Gin", "drink", 110, null, "Gin.jpg"],
    ["Vodka", "drink", 120, null, "Vondka.webp"],
    ["Whisky", "drink", 150, null, "Whisky.webp"],
    ["Wine", "drink", 140, null, "Wne.webp"],
    ["Beer", "drink", 45, null, "Beer.jpg"],
    ["Fanta", "drink", 20, null, "Fanta.webp"],
    ["Coca-Cola", "drink", 20, null, "Coca-Cola.jpg"],
    ["Water", "drink", 10, null, "Water.webp"],
    ["Mango Juice", "drink", 30, null, "mangi juice.avif"],
    ["Orange Juice", "drink", 30, null, "Juice(Mango,Orange,Pineapple).avif"], // shared image
    ["Pineapple Juice", "drink", 30, null, "Juice(Mango,Orange,Pineapple).avif"], // shared
    ["Sprite", "drink", 20, null, "Sprite.jpg"],
    ["Milk", "drink", 15, null, "Milk.jpg"],
    ["Hot Chocolate", "drink", 35, null, "Hot Chocolate.webp"],
    ["Tea", "drink", 10, null, "Tea.jpg"],
    ["Pepsi", "drink", 20, null, "Pepsi.jpg"]
];

// Banks for account payments
let banks = [
    'Commercial Bank of Ethiopia (CBE)',
    'Awash Bank',
    'Bank of Abyssinia (BOA)',
    'Bunna Bank',
    'Dashen Bank',
    'Wegagen Bank',
    'Abay Bank',
    'Hibret Bank',
    'Zemen Bank',
    'Oromia Bank'
];

// ==================== TRANSLATIONS ====================
const TRANSLATIONS = {
    en: {
        search: 'Search',
        food: 'Food Items',
        drink: 'Drink Items',
        checkout: 'Checkout',
        payment: 'Payment Method:',
        cash: 'Cash',
        account: 'Account',
        accountType: 'Account / Bank',
        accountNumber: 'Account Number',
        calculate: 'Calculate Total',
        total: 'Total:',
        home: 'Home',
        admin: 'Admin',
        contact: 'Contact',
        addPanel: 'Add/Edit Panel',
        addItem: 'Add Item',
        updateItem: 'Update Item',
        clear: 'Clear',
        existingItems: 'Existing Items',
        edit: 'Edit',
        delete: 'Delete',
        price: 'Price',
        loginHeader: 'Admin Login',
        username: 'Username',
        password: 'Password',
        login: 'Login',
        logout: 'Logout',
        searchPlaceholder: 'Search...',
        itemNamePh: 'Item Name',
        price1Ph: 'Price 1 (e.g. 100)',
        price2Ph: 'Price 2 (optional)',
        typeFoodLabel: 'Food',
        typeDrinkLabel: 'Drink'
    },
    am: {
        search: 'ፈልግ',
        food: 'የምግብ እቃዎች',
        drink: 'የንግድ መጠጦች',
        checkout: 'ክፍያ',
        payment: 'የክፍያ ዘዴ፡',
        cash: 'ቢር',
        account: 'አካውንት',
        accountType: 'አካውንት / ባንክ',
        accountNumber: 'የአካውንት ቁጥር',
        calculate: 'ጠቅላላ ዋጋን ይቁጥሩ',
        total: 'ጠቅላላ:',
        home: 'መነሻ',
        admin: 'አስተዳዳሪ',
        contact: 'እኛን ተገናኝ',
        addPanel: 'መጨመሪያ/ማስተካከያ ፓነል',
        addItem: 'እቃ ጨምር',
        updateItem: 'እቃ አዘምን',
        clear: 'አጽዳ',
        existingItems: 'ያሉ እቃዎች',
        edit: 'አርም',
        delete: 'ሰርዝ',
        price: 'ዋጋ',
        loginHeader: 'የአስተዳዳሪ መግቢያ',
        username: 'የተጠቃሚ ስም',
        password: 'የመክፈቻ ቁልፍ',
        login: 'ግባ',
        logout: 'ውሰድ',
        searchPlaceholder: 'ፈልግ...',
        itemNamePh: 'የእቃ ስም',
        price1Ph: 'ዋጋ 1 (ለምሳሌ 100)',
        price2Ph: 'ዋጋ 2 (አማራጭ)',
        typeFoodLabel: 'ምግብ',
        typeDrinkLabel: 'መጠጥ'
    },
    om: {
        search: 'Barbaadi',
        food: 'Soorata',
        drink: 'Dhugaatii',
        checkout: 'Gatii',
        payment: 'Mala Kaffaltii:',
        cash: 'Maallaqa',
        account: 'Herrega',
        accountType: 'Herrega / Baanki',
        accountNumber: 'Lakkoofsa Herregaa',
        calculate: 'Walitti Qabuu',
        total: 'Waliigala:',
        home: 'Mana',
        admin: 'Admin',
        contact: 'Nu Qunnamuu',
        addPanel: 'Panel Dabalataa/Gulaalaa',
        addItem: 'Item Dabaladhu',
        updateItem: 'Item Sirreessi',
        clear: 'Qulqullaa\'i',
        existingItems: 'Items Jiran',
        edit: 'Gulaali',
        delete: 'Haqu',
        price: 'Gatii',
        loginHeader: 'Admin Seensa',
        username: 'Maqaa Fayyadamaa',
        password: 'Jechoota Iccitii',
        login: 'Seensa',
        logout: 'Ba\'i',
        searchPlaceholder: 'Barbaadi...',
        itemNamePh: 'Maqaa Iteemii',
        price1Ph: 'Gatii 1 (fakkeenya 100)',
        price2Ph: 'Gatii 2 (filannoo)',
        typeFoodLabel: 'Nyaata',
        typeDrinkLabel: 'Dhugeessaa'
    },
    aa: {
        search: 'Baaxal',
        food: 'Soorata',
        drink: 'Sharbuu',
        checkout: 'Gabaabaa',
        payment: 'Maaloo:',
        cash: 'Maallaqa',
        account: 'Akkawuntii',
        accountType: 'Akkawuntii / Baankii',
        accountNumber: 'Lakkoofsa Akkawuntii',
        calculate: 'Waliigalu',
        total: 'Walii:',
        home: 'Mana',
        admin: 'Admin',
        contact: 'Nu Qadaadi',
        addPanel: 'Panel Dabalataa/Gulaalaa',
        addItem: 'Item Dabaladhu',
        updateItem: 'Item Sirreessi',
        clear: 'Qulqullaa\'i',
        existingItems: 'Items Jiran',
        edit: 'Gulaali',
        delete: 'Haqu',
        price: 'Gatii',
        loginHeader: 'Admin Seensa',
        username: 'Maqaa Fayyadamaa',
        password: 'Jechoota Iccitii',
        login: 'Seensa',
        logout: 'Ba\'i',
        searchPlaceholder: 'Baaxal...',
        itemNamePh: 'Magaca Shayga',
        price1Ph: 'Qiimo 1 (tusaale 100)',
        price2Ph: 'Qiimo 2 (ikhtiyaar)',
        typeFoodLabel: 'Soorata',
        typeDrinkLabel: 'Sharbuu'
    },
    so: {
        search: 'Raadi',
        food: 'Cuntada',
        drink: 'Cabitaanka',
        checkout: 'Lacag bixinta',
        payment: 'Habka Lacag-bixinta:',
        cash: 'Lacag',
        account: 'Akaawn',
        accountType: 'Akaawn / Baank',
        accountNumber: 'Nambarka Akaawnka',
        calculate: 'Xisaabi Wadarta',
        total: 'Wadarta:',
        home: 'Guriga',
        admin: 'Maamul',
        contact: 'Nala Soo Xiriir',
        addPanel: 'Guddiga Daraasad/Dhismeed',
        addItem: 'Ku Dar Alaab',
        updateItem: 'Cusboonaysii Alaabta',
        clear: 'Nadiifi',
        existingItems: 'Alaabta Jira',
        edit: 'Wax ka beddel',
        delete: 'Tirtir',
        price: 'Qiimo',
        loginHeader: 'Admin Soo Gal',
        username: 'Magaca Isticmaale',
        password: 'Ereyga Sirta',
        login: 'Soo Gal',
        logout: 'Ka Bax',
        searchPlaceholder: 'Raadi...',
        itemNamePh: 'Magaca Alaabta',
        price1Ph: 'Qiimaha 1 (tusaale 100)',
        price2Ph: 'Qiimaha 2 (ikhtiyaari)',
        typeFoodLabel: 'Cunto',
        typeDrinkLabel: 'Cabitaan'
    }
};

// ==================== STATE VARIABLES ====================
let currentLang = 'en';
let foods = [];
let drinks = [];
let adminItems = [];
let editingIndex = -1;
let currentAdminImageData = null;

// ==================== CORE FUNCTIONS ====================
function formatPriceHtml(p1, p2) {
    const p1val = (p1 !== undefined && p1 !== null) ? p1 : DEFAULT_PRICE;
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
    
    const priceHtml = (p2 !== undefined && p2 !== null)
        ? `<p class="price">${t.price}: ${p1val} Birr / ${p2} Birr</p>`
        : `<p class="price">${t.price}: ${p1val} Birr</p>`;
        
    const priceOptionHtml = (p2 !== undefined && p2 !== null)
        ? `<select class="priceOption">
            <option value="${p1val}">${p1val} Birr</option>
            <option value="${p2}">${p2} Birr</option>
           </select>`
        : `<input type="hidden" class="priceOption" value="${p1val}">`;
        
    return { priceHtml, priceOptionHtml };
}

function showSection(id) {
    document.querySelectorAll(".page-section").forEach(sec => {
        sec.classList.add("hidden");
    });
    document.getElementById(id).classList.remove("hidden");
    
    // Show/hide logout button
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.style.display = (id === 'admin' && isLoggedIn()) ? 'flex' : 'none';
    }
}

function createCard(name, container, price1, price2, image, showAdminControls = false) {
    const card = document.createElement("div");
    card.className = "card";
    card.dataset.enName = name;
    
    const { priceHtml, priceOptionHtml } = formatPriceHtml(price1, price2);
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
    
    function getDisplayNameByEnglishName(en) {
        let item = foods.find(f => f.name === en) || drinks.find(d => d.name === en);
        if (item && item.names && item.names[currentLang] && currentLang !== 'en') {
            return `${item.names[currentLang]} (${item.name})`;
        }
        return en;
    }
    
    card.innerHTML = `
        <h3>${getDisplayNameByEnglishName(name)}</h3>
        ${priceHtml}
        ${priceOptionHtml}
        <img class="preview-img ${image ? 'has-image' : ''}" src="${image || ''}" alt="${name}">
        <input type="file" accept="image/*" onchange="previewImage(event, this)">
        <div class="qty">
            <button type="button" onclick="changeQty(this, -1)">-</button>
            <input class="qty-input" type="number" min="0" value="0" onchange="calculateTotal()">
            <button type="button" onclick="changeQty(this, 1)">+</button>
        </div>
        ${showAdminControls ? `
        <div class="admin-actions">
            <button type="button" class="edit-btn" onclick="editMenuItemByName('${name}')">
                <i class="fas fa-edit"></i> ${t.edit}
            </button>
            <button type="button" class="delete-btn" onclick="deleteMenuItemByName('${name}')">
                <i class="fas fa-trash"></i> ${t.delete}
            </button>
        </div>
        ` : ''}
    `;
    
    container.appendChild(card);
}

function changeQty(btn, delta) {
    const input = btn.parentElement.querySelector('.qty-input');
    if (!input) return;
    let v = Number(input.value) || 0;
    v = Math.max(0, v + delta);
    input.value = v;
    calculateTotal();
}

function searchItems() {
    const query = document.getElementById("searchBox").value.toLowerCase();
    document.querySelectorAll("#foodContainer .card, #drinkContainer .card").forEach(card => {
        const name = card.querySelector("h3").textContent.toLowerCase();
        card.style.display = name.includes(query) ? "block" : "none";
    });
}

// ==================== CHECKOUT FUNCTIONS ====================
function populateAccounts() {
    const sel = document.getElementById('accountType');
    if (!sel) return;
    sel.innerHTML = '';
    
    banks.forEach(b => {
        const opt = document.createElement('option');
        opt.value = b;
        opt.textContent = b;
        sel.appendChild(opt);
    });
    
    if (sel.options.length > 0) {
        sel.selectedIndex = 0;
        sel.disabled = false;
    } else {
        sel.disabled = true;
    }
}

function onPaymentChange(value) {
    const acc = document.getElementById('accountFields');
    if (!acc) return;
    acc.style.display = value === 'account' ? 'block' : 'none';
}

function calculateTotal() {
    let total = 0;
    
    document.querySelectorAll('#foodContainer .card, #drinkContainer .card').forEach(card => {
        const qtyEl = card.querySelector('.qty-input');
        const priceEl = card.querySelector('.priceOption');
        const qty = qtyEl ? Number(qtyEl.value) || 0 : 0;
        let price = DEFAULT_PRICE;
        
        if (priceEl) {
            if (priceEl.tagName === 'SELECT') {
                price = Number(priceEl.value) || DEFAULT_PRICE;
            } else {
                price = Number(priceEl.value) || DEFAULT_PRICE;
            }
        }
        
        total += qty * price;
    });
    
    const payment = document.querySelector('input[name="payment"]:checked');
    let paymentText = payment ? payment.value : 'cash';
    
    if (paymentText === 'account') {
        const accType = document.getElementById('accountType').value;
        const accNum = document.getElementById('accountNumber').value || '(none)';
        paymentText = `Account (${accType}) ${accNum}`;
    } else {
        paymentText = 'Cash';
    }
    
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
    const totalDisplay = document.getElementById('totalDisplay');
    if (totalDisplay) {
        document.getElementById('totalLabel').textContent = t.total;
        totalDisplay.querySelector('.total-amount').textContent = `${total} Birr (${paymentText})`;
    }
    
    return total;
}

// ==================== LANGUAGE FUNCTIONS ====================
function setLanguage(lang) {
    currentLang = lang;
    const t = TRANSLATIONS[lang] || TRANSLATIONS.en;
    
    // Update all text elements
    const elements = {
        'searchLabel': t.search,
        'foodHeader': t.food,
        'drinkHeader': t.drink,
        'checkoutHeader': t.checkout,
        'paymentLabel': t.payment,
        'accountTypeLabel': t.accountType,
        'accountNumberLabel': t.accountNumber,
        'calculateBtn': t.calculate,
        'homeNavBtn': t.home,
        'adminNavBtn': t.admin,
        'contactNavBtn': t.contact,
        'cashLabel': t.cash,
        'accountLabel': t.account,
        'adminHeader': t.addPanel,
        'existingItemsHeader': t.existingItems,
        'loginHeader': t.loginHeader,
        'loginBtn': t.login,
        'logoutBtn': t.logout,
        'usernameLabel': t.username,
        'passwordLabel': t.password
    };
    
    Object.keys(elements).forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            if (el.tagName === 'BUTTON' && el.querySelector('span')) {
                el.querySelector('span').textContent = elements[id];
            } else {
                el.textContent = elements[id];
            }
        }
    });
    
    // Update placeholders
    const searchBox = document.getElementById('searchBox');
    const loginUsername = document.getElementById('loginUsername');
    const loginPassword = document.getElementById('loginPassword');
    const addItemBtn = document.getElementById('addItemBtn');
    const itemNameEl = document.getElementById('itemName');
    const itemPrice1El = document.getElementById('itemPrice1');
    const itemPrice2El = document.getElementById('itemPrice2');
    const itemTypeEl = document.getElementById('itemType');
    
    if (searchBox) searchBox.placeholder = t.searchPlaceholder;
    if (loginUsername) loginUsername.placeholder = t.username;
    if (loginPassword) loginPassword.placeholder = t.password;
    if (itemNameEl) itemNameEl.placeholder = t.itemNamePh;
    if (itemPrice1El) itemPrice1El.placeholder = t.price1Ph;
    if (itemPrice2El) itemPrice2El.placeholder = t.price2Ph;
    if (itemTypeEl && itemTypeEl.options && itemTypeEl.options.length >= 2) {
        itemTypeEl.options[0].textContent = t.typeFoodLabel;
        itemTypeEl.options[1].textContent = t.typeDrinkLabel;
    }
    
    // Update add/update button text
    if (addItemBtn) {
        addItemBtn.innerHTML = `<i class="fas fa-${editingIndex !== -1 ? 'save' : 'plus'}"></i> ${editingIndex !== -1 ? t.updateItem : t.addItem}`;
    }
    
    // Update account number placeholder
    const accountNumber = document.getElementById('accountNumber');
    if (accountNumber) {
        accountNumber.placeholder = t.accountNumber;
    }
    
    // Reload menu items with new language
    loadHomeItems();
    loadAdminMenu();
    calculateTotal();
}

// ==================== IMAGE FUNCTIONS ====================
function previewImage(event, input) {
    const reader = new FileReader();
    const img = input.previousElementSibling;
    
    reader.onload = () => {
        img.src = reader.result;
        img.classList.add('has-image');
        
        // Find and update the item in arrays
        const card = input.closest('.card');
        const enName = card && card.dataset ? card.dataset.enName : null;
        const nameText = card ? card.querySelector('h3').textContent.trim() : null;
        const key = enName || nameText;
        
        // Update in foods
        let item = foods.find(f => f.name === key);
        if (item) {
            item.image = reader.result;
        }
        
        // Update in drinks
        if (!item) {
            item = drinks.find(d => d.name === key);
            if (item) item.image = reader.result;
        }
        
        // Update in adminItems
        const adminItem = adminItems.find(a => a.name === key);
        if (adminItem) adminItem.image = reader.result;
        
        saveAll();
    };
    
    if (input.files[0]) reader.readAsDataURL(input.files[0]);
}

function previewAdminImage(event) {
    const reader = new FileReader();
    const img = document.getElementById('adminPreview');
    const previewText = document.querySelector('.preview-text');
    
    reader.onload = () => {
        img.src = reader.result;
        img.classList.add('has-image');
        if (previewText) previewText.style.display = 'none';
        currentAdminImageData = reader.result;
    };
    
    if (event.target.files[0]) reader.readAsDataURL(event.target.files[0]);
}

// ==================== ADMIN FUNCTIONS ====================
function initAdminItemsFromDefaults() {
    adminItems = [];
    
    // Add foods to admin items
    foods.forEach(f => {
        adminItems.push({
            name: f.name,
            names: f.names || { en: f.name },
            type: 'food',
            price1: f.price1,
            price2: f.price2,
            image: f.image
        });
    });
    
    // Add drinks to admin items
    drinks.forEach(d => {
        adminItems.push({
            name: d.name,
            names: d.names || { en: d.name },
            type: 'drink',
            price1: d.price1,
            price2: d.price2,
            image: d.image
        });
    });
}

function loadHomeItems() {
    const foodContainer = document.getElementById("foodContainer");
    const drinkContainer = document.getElementById("drinkContainer");
    
    if (foodContainer) foodContainer.innerHTML = "";
    if (drinkContainer) drinkContainer.innerHTML = "";
    
    foods.forEach(f => createCard(f.name, foodContainer, f.price1, f.price2, f.image, false));
    drinks.forEach(d => createCard(d.name, drinkContainer, d.price1, d.price2, d.image, false));
}

function addMenuItem() {
    const name = document.getElementById("itemName").value.trim();
    const name_am = (document.getElementById("itemName_am").value || '').trim();
    const name_om = (document.getElementById("itemName_om").value || '').trim();
    const name_aa = (document.getElementById("itemName_aa").value || '').trim();
    const name_so = (document.getElementById("itemName_so").value || '').trim();
    const type = document.getElementById("itemType").value;
    const price1 = document.getElementById("itemPrice1").value.trim();
    const price2 = document.getElementById("itemPrice2").value.trim();
    
    if (!name) {
        alert("Please enter item name");
        return;
    }
    
    const newItem = {
        name: name,
        names: {
            en: name,
            am: name_am || undefined,
            om: name_om || undefined,
            aa: name_aa || undefined,
            so: name_so || undefined
        },
        type: type,
        price1: price1 ? Number(price1) : null,
        price2: price2 ? Number(price2) : null,
        image: currentAdminImageData
    };
    
    if (editingIndex !== -1) {
        // Update existing item
        const oldItem = adminItems[editingIndex];
        
        // Preserve image if no new image was selected
        if (!newItem.image && oldItem.image) {
            newItem.image = oldItem.image;
        }
        // Preserve names not provided
        const oldNames = oldItem.names || { en: oldItem.name };
        newItem.names = {
            en: newItem.names.en || oldNames.en,
            am: newItem.names.am || oldNames.am,
            om: newItem.names.om || oldNames.om,
            aa: newItem.names.aa || oldNames.aa,
            so: newItem.names.so || oldNames.so
        };
        
        // Update adminItems
        adminItems[editingIndex] = newItem;
        
        // Update foods/drinks arrays
        if (oldItem.type === "food") {
            const idx = foods.findIndex(f => f.name === oldItem.name);
            if (idx !== -1) foods.splice(idx, 1);
        } else if (oldItem.type === "drink") {
            const idx = drinks.findIndex(d => d.name === oldItem.name);
            if (idx !== -1) drinks.splice(idx, 1);
        }
        
        // Add to appropriate array
        if (type === "food") {
            foods.push({
                name: newItem.name,
                names: newItem.names,
                price1: newItem.price1,
                price2: newItem.price2,
                image: newItem.image
            });
        } else {
            drinks.push({
                name: newItem.name,
                names: newItem.names,
                price1: newItem.price1,
                price2: newItem.price2,
                image: newItem.image
            });
        }
        
        editingIndex = -1;
    } else {
        // Add new item
        adminItems.push(newItem);
        
        if (type === "food") {
            foods.push({
                name: newItem.name,
                names: newItem.names,
                price1: newItem.price1,
                price2: newItem.price2,
                image: newItem.image
            });
        } else {
            drinks.push({
                name: newItem.name,
                names: newItem.names,
                price1: newItem.price1,
                price2: newItem.price2,
                image: newItem.image
            });
        }
    }
    
    loadAdminMenu();
    loadHomeItems();
    clearAdminForm();
    saveAll();
    
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
    alert(editingIndex !== -1 ? t.updateItem + " successful!" : t.addItem + " successful!");
}

function clearAdminForm() {
    document.getElementById("itemName").value = "";
    const n_am = document.getElementById("itemName_am"); if (n_am) n_am.value = "";
    const n_om = document.getElementById("itemName_om"); if (n_om) n_om.value = "";
    const n_aa = document.getElementById("itemName_aa"); if (n_aa) n_aa.value = "";
    const n_so = document.getElementById("itemName_so"); if (n_so) n_so.value = "";
    document.getElementById("itemType").value = "food";
    document.getElementById("itemPrice1").value = "";
    document.getElementById("itemPrice2").value = "";
    
    const img = document.getElementById("adminPreview");
    img.src = "";
    img.classList.remove("has-image");
    
    const previewText = document.querySelector('.preview-text');
    if (previewText) previewText.style.display = 'block';
    
    document.getElementById("itemImage").value = "";
    
    currentAdminImageData = null;
    editingIndex = -1;
    
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
    const addItemBtn = document.getElementById("addItemBtn");
    if (addItemBtn) {
        addItemBtn.innerHTML = `<i class="fas fa-plus"></i> ${t.addItem}`;
    }
}

function editMenuItem(index) {
    const item = adminItems[index];
    if (!item) return;
    
    document.getElementById("itemName").value = item.name;
    const n_am = document.getElementById("itemName_am"); if (n_am) n_am.value = (item.names && item.names.am) || "";
    const n_om = document.getElementById("itemName_om"); if (n_om) n_om.value = (item.names && item.names.om) || "";
    const n_aa = document.getElementById("itemName_aa"); if (n_aa) n_aa.value = (item.names && item.names.aa) || "";
    const n_so = document.getElementById("itemName_so"); if (n_so) n_so.value = (item.names && item.names.so) || "";
    document.getElementById("itemType").value = item.type;
    document.getElementById("itemPrice1").value = item.price1 || "";
    document.getElementById("itemPrice2").value = item.price2 || "";
    
    const img = document.getElementById("adminPreview");
    const previewText = document.querySelector('.preview-text');
    if (item.image) {
        img.src = item.image;
        img.classList.add("has-image");
        if (previewText) previewText.style.display = 'none';
        currentAdminImageData = item.image;
    } else {
        img.src = "";
        img.classList.remove("has-image");
        if (previewText) previewText.style.display = 'block';
        currentAdminImageData = null;
    }
    
    editingIndex = index;
    
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
    const addItemBtn = document.getElementById("addItemBtn");
    if (addItemBtn) {
        addItemBtn.innerHTML = `<i class="fas fa-save"></i> ${t.updateItem}`;
    }
    
    // Scroll to form
    document.querySelector('.admin-form').scrollIntoView({ behavior: 'smooth' });
}

function editMenuItemByName(name) {
    const idx = adminItems.findIndex(a => a.name === name);
    if (idx !== -1) {
        editMenuItem(idx);
        showSection('admin');
    }
}

function deleteMenuItem(index) {
    const item = adminItems[index];
    if (!item) return;
    
    if (confirm(`Are you sure you want to delete "${item.name}"?`)) {
        adminItems.splice(index, 1);
        
        // Remove from foods/drinks arrays
        if (item.type === "food") {
            const idx = foods.findIndex(f => f.name === item.name);
            if (idx !== -1) foods.splice(idx, 1);
        } else {
            const idx = drinks.findIndex(d => d.name === item.name);
            if (idx !== -1) drinks.splice(idx, 1);
        }
        
        loadAdminMenu();
        loadHomeItems();
        saveAll();
        
        const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
        alert(t.delete + " successful!");
    }
}

function deleteMenuItemByName(name) {
    const idx = adminItems.findIndex(a => a.name === name);
    if (idx !== -1) {
        deleteMenuItem(idx);
    } else {
        // Try to find in foods/drinks directly
        const foodIdx = foods.findIndex(f => f.name === name);
        if (foodIdx !== -1) {
            foods.splice(foodIdx, 1);
        }
        
        const drinkIdx = drinks.findIndex(d => d.name === name);
        if (drinkIdx !== -1) {
            drinks.splice(drinkIdx, 1);
        }
        
        loadHomeItems();
        saveAll();
    }
}

function loadAdminMenu() {
    const adminMenu = document.getElementById("adminMenu");
    if (!adminMenu) return;
    
    adminMenu.innerHTML = "";
    const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;
    
    adminItems.forEach((item, index) => {
        const p1 = item.price1 !== null && item.price1 !== undefined ? item.price1 : DEFAULT_PRICE;
        const priceHtml = item.price2 !== null && item.price2 !== undefined 
            ? `${t.price}: ${p1} Birr / ${item.price2} Birr`
            : `${t.price}: ${p1} Birr`;
        const dispName = (item.names && item.names[currentLang] && currentLang !== 'en')
            ? `${item.names[currentLang]} (${item.name})`
            : item.name;
        
        const card = document.createElement("div");
        card.className = "card";
        card.dataset.enName = item.name;
        card.innerHTML = `
            <h3>${dispName} (${item.type})</h3>
            <img class="preview-img ${item.image ? 'has-image' : ''}" src="${item.image || ''}" alt="${item.name}">
            <p class="price">${priceHtml}</p>
            <div class="admin-actions">
                <button class="edit-btn" onclick="editMenuItem(${index})">
                    <i class="fas fa-edit"></i> ${t.edit}
                </button>
                <button class="delete-btn" onclick="deleteMenuItem(${index})">
                    <i class="fas fa-trash"></i> ${t.delete}
                </button>
            </div>
        `;
        
        adminMenu.appendChild(card);
    });
}

// ==================== LOGIN FUNCTIONS ====================
function isLoggedIn() {
    return localStorage.getItem('adminLoggedIn') === 'true';
}

function openAdmin() {
    if (isLoggedIn()) {
        showSection('admin');
    } else {
        showSection('login');
    }
}

function onLogin() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        localStorage.setItem('adminLoggedIn', 'true');
        showSection('admin');
    } else {
        alert('Invalid username or password');
    }
}

function logout() {
    localStorage.removeItem('adminLoggedIn');
    showSection('home');
    clearAdminForm();
}

// ==================== STORAGE FUNCTIONS ====================
function saveAll() {
    try {
        localStorage.setItem('foods', JSON.stringify(foods));
        localStorage.setItem('drinks', JSON.stringify(drinks));
        localStorage.setItem('adminItems', JSON.stringify(adminItems));
        localStorage.setItem('banks', JSON.stringify(banks));
        localStorage.setItem('language', currentLang);
    } catch (e) {
        console.error('Error saving data:', e);
    }
}

function loadSavedData() {
    // Clear old data to reload from defaults with images
    localStorage.removeItem('foods');
    localStorage.removeItem('drinks');
    try {
        // Load foods
        const savedFoods = JSON.parse(localStorage.getItem('foods'));
        if (savedFoods && Array.isArray(savedFoods)) {
            foods = savedFoods;
        } else {
            // Initialize from defaults
            foods = DEFAULT_ITEMS
                .filter(i => i[1] === "food")
                .map(i => ({ 
                    name: i[0], 
                    names: { en: i[0] },
                    price1: i[2], 
                    price2: i[3], 
                    image: i[4] 
                }));
        }
        
        // Load drinks
        const savedDrinks = JSON.parse(localStorage.getItem('drinks'));
        if (savedDrinks && Array.isArray(savedDrinks)) {
            drinks = savedDrinks;
        } else {
            drinks = DEFAULT_ITEMS
                .filter(i => i[1] === "drink")
                .map(i => ({ 
                    name: i[0], 
                    names: { en: i[0] },
                    price1: i[2], 
                    price2: i[3], 
                    image: i[4] 
                }));
        }
        
        // Load admin items
        const savedAdminItems = JSON.parse(localStorage.getItem('adminItems'));
        if (savedAdminItems && Array.isArray(savedAdminItems)) {
            adminItems = savedAdminItems;
        } else {
            initAdminItemsFromDefaults();
        }
        
        // Load banks
        const savedBanks = JSON.parse(localStorage.getItem('banks'));
        if (savedBanks && Array.isArray(savedBanks)) {
            banks = savedBanks;
        }
        
        // Load language
        const savedLang = localStorage.getItem('language');
        if (savedLang && TRANSLATIONS[savedLang]) {
            currentLang = savedLang;
            document.getElementById('languageSelect').value = savedLang;
        }
        
    } catch (e) {
        console.error('Error loading saved data:', e);
        // Initialize with defaults on error
        foods = DEFAULT_ITEMS
            .filter(i => i[1] === "food")
            .map(i => ({ 
                name: i[0], 
                price1: i[2], 
                price2: i[3], 
                image: null 
            }));
            
        drinks = DEFAULT_ITEMS
            .filter(i => i[1] === "drink")
            .map(i => ({ 
                name: i[0], 
                price1: i[2], 
                price2: i[3], 
                image: null 
            }));
            
        initAdminItemsFromDefaults();
    }
}

// ==================== INITIALIZATION ====================
function initializeApp() {
    // Load saved data
    loadSavedData();
    
    // Set up language
    setLanguage(currentLang);
    
    // Populate accounts
    populateAccounts();
    
    // Load initial data
    loadHomeItems();
    loadAdminMenu();
    
    // Show home section
    showSection('home');
    
    // Set up event listeners
    document.getElementById('searchBox').addEventListener('input', searchItems);
    
    // Auto-calculate total when quantities change
    document.addEventListener('input', function(e) {
        if (e.target.classList.contains('qty-input') || e.target.classList.contains('priceOption')) {
            calculateTotal();
        }
    });
    
    // Set initial total
    calculateTotal();
    
    // Set up payment method change
    document.querySelectorAll('input[name="payment"]').forEach(radio => {
        radio.addEventListener('change', function() {
            onPaymentChange(this.value);
            calculateTotal();
        });
    });
}

// Start the application
window.onload = initializeApp;

// Add event listener for add item button
document.addEventListener('DOMContentLoaded', function() {
    const addItemBtn = document.getElementById('addItemBtn');
    if (addItemBtn) {
        addItemBtn.addEventListener('click', addMenuItem);
    }
});
